package exercise1;


    public class Student extends Human{

        private int studentNumber;
        private String majorName;
        private String universityName;

        public int getStudentNumber(){
            return studentNumber;
        }
        public void setStudentNumber(int studentNumber){
            this.studentNumber=studentNumber;
        }
        public String getMajorName(){
            return majorName;
        }
        public void setMajorName(String majorName){
            this.majorName=majorName;
        }
       public String getUniversityName(){
            return universityName;
       }
       public void setUniversityName(String universityName){
            this.universityName=universityName;
       }


        @Override

        public void sayMyName(){
            System.out.println("My name is  " + getFullName());

        }
    }
