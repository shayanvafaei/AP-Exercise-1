package exercise1;

import java.util.ArrayList;
import java.util.List;

 
public class Main {
    public static void main(String[] args) {

        Human student=new Student();
        Human professor=new Professor();

        System.out.println(student instanceof Human); //true
        System.out.println(professor instanceof Human); //true


        Human human1=new Student();
        human1.sayMyName();
        //output:My name is  null


        Human human2 = new Professor();
        human2.sayMyName();
        /* output:
        My name is null
        The professorFaculty is null
         */
    }
}
